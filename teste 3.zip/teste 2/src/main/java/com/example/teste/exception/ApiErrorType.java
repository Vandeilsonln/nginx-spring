package com.example.teste.exception;

public enum ApiErrorType {
    PAYLOAD_INVALID,
    MALFORMED_VALUE_TYPE
}
