package com.example.teste.service;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ExtratoService {

    public void getExtrato() {
        return;
    }

}
