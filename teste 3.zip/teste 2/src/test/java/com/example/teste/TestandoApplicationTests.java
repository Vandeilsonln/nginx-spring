package com.example.teste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestandoApplicationTests {

	@Test
	void contextLoads() {
	}

}
